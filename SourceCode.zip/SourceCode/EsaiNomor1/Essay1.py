from nltk import CFG,parse

text1 = ["she", "books", "plane", "ticket", "at", "the", "mall"]
text2 = ["a","man","buys","a","book", "on", "the", "shop"]
text3 = ["the","kids","play","ball", "in", "the", "house"]

grammar = CFG.fromstring("""
 S -> NP VP
 PP -> P NP
 NP -> Det N | NP PP
 VP -> V NP | VP PP
 Det -> 'the' | 'a' | 'an'
 N -> 'she' | 'man' | 'kids' | 'plane' | 'ticket' | 'book' | 'mall' | 'shop' | 'ball' | 'house'
 V -> 'buys' | 'books' | 'play' | 'ate'
 P -> 'on' | 'in' | 'at'
 """)
 
def init_wfst(tokens, grammar):
    numtokens = len(tokens)
    # fill w/ dots
    wfst = [["." for i in range(numtokens+1)]
            for j in range(numtokens+1)]
    for i in range(numtokens):
        productions = grammar.productions(rhs=tokens[i])
        wfst[i][i+1] = productions[0].lhs()
    return wfst 

def complete_wfst(wfst, tokens, trace=False): 
    index={}
    for prod in grammar.productions():
        index[prod.rhs()] = prod.lhs()
    numtokens = len(tokens)
    for span in range(2, numtokens+1):
        for start in range(numtokens+1-span):
            end = start + span
            for mid in range(start+1, end): 
                nt1, nt2 = wfst[start][mid], wfst[mid][end] 
                if (nt1,nt2) in index:
                    if trace:
                        print("[%s] %3s [%s] %3s [%s] ==> [%s] %3s [%s]") % \
                        (start, nt1, mid, nt2, end, start, index[(nt1,nt2)], end)
                    wfst[start][end] = index[(nt1,nt2)]
    return wfst    


def display(wfst,tokens):
        print (" ".join([("%-6s" % tokens[i]) for i in range(0, len(tokens))])) 
        for i in range(len(wfst)-1):
            print (" ".join(["%-6s" % wfst[i][j] for j in range(1, len(wfst))]))
            print("")
        print("\n\n\n")

wfst1 = init_wfst(text1, grammar)
wfst2 = init_wfst(text2, grammar)
wfst3 = init_wfst(text3, grammar)

display(wfst1, text1)
display(wfst2, text2)
display(wfst3, text3)

print("This is the complete result\n")

complete_wfst1 = complete_wfst(wfst1, text1)
complete_wfst2 = complete_wfst(wfst2, text2)
complete_wfst3 = complete_wfst(wfst3, text3)

display(complete_wfst1, text1)
display(complete_wfst2, text2)
display(complete_wfst3, text3)




